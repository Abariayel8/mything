>>> Unzip ur files
>>> Download ngrok and run ngrok.exe http 5000
>>> Download python

>>> open terminal and install modules
    >>> pip install flask
    >>> pip install requests
    >>> pip install phonenumbers
    >>> pip install twilio
    >>> pip install pyTelegramBotAPI

✳️Open cred.py and replace with ur data 
✳️open connect dbase file for host it
✳️open terminal and Run Python mainn.py
